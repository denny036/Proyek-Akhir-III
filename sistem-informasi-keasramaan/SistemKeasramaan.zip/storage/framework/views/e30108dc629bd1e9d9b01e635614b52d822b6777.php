

<?php $__env->startSection('title'); ?>
    <title>Portal Mahasiswa</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('mahasiswa.izin-sakit')); ?>"><span class="text-gray-600">Izin Sakit / </a></span>Data Izin
    Sakit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-2">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <p class="font-poppins font-normal text-lg py-2">Detail Izin Sakit</p>

    <div class="bg-white shadow rounded-sm my-2.5 overflow-x-auto">

        <table class="min-w-max w-full table-auto">

            <?php $__currentLoopData = $detailIS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="text-gray-600 text-sm">
                    <tr class="border-b bg-slate-200 border-gray-200 ">
                        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins font-bold">
                            Nama Mahasiswa
    </div>
    </td>
    <td class="py-3 px-6 text-left">
        <div class="flex items-center">
            <span class="font-poppins">
                <?php echo e($data->nama); ?>

            </span>
        </div>
    </td>
    </tr>

    <tr class="border-b border-gray-200 ">
        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins font-bold">
            NIM Mahasiswa
        </td>
        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
            <?php echo e($data->nim); ?>

        </td>
    </tr>

    <tr class="border-b bg-slate-200 border-gray-200 ">
        <td class="py-3 px-6 text-left font-poppins font-bold">
            Mulai Istirahat
        </td>

        <td class="py-3 px-6 text-left font-poppins">
            <?php echo e(\Carbon\Carbon::parse($data->jadwal_istirahat)->isoFormat('DD MMMM YYYY H:mm')); ?>

        </td>
    </tr>

    <tr class="border-b border-gray-200 ">
        <td class="py-3 px-6 text-left font-poppins font-bold">
            Kondisi
        </td>

        <td class="py-3 px-3 text-center font-poppins">
            <?php if($data->kondisi == "sakit"): ?>
                <div class="flex">
                    <span class="font-poppins py-1 px-3 rounded text-sm">
                        Sakit
                    </span>
                </div>
            <?php else: ?>
                <div class="flex">
                    <span class="font-poppins py-1 px-3 rounded text-sm">
                        Sembuh
                    </span>
                </div>
            <?php endif; ?>
        </td>
    </tr>

    <tr class="border-b bg-slate-200 bg-slate-200border-gray-100 ">
        <td class="py-3 px-6 text-left font-poppins font-bold">
            Keterangan
        </td>

        <td class="py-3 px-6 text-left font-poppins">
            <?php echo e($data->keterangan); ?>

        </td>
    </tr>

    <tr class="border-b border-gray-200 ">
        <td class="py-3 px-6 text-left font-poppins font-bold">
            Surat Sakit (*jika ada)
        </td>

        <td class="py-3 px-6 text-left font-poppins">
            <?php if($data->surat_sakit): ?> 
            <img src="<?php echo e(asset('uploads/surat-sakit/' . $data->surat_sakit)); ?>" class="w-32 rounded-full" alt="Surat Sakit">
            <?php else: ?>
            <p class="font-semibold">Anda tidak memiliki surat sakit</p>
            <?php endif; ?>
        </td>
    </tr>

    <tr class="border-b bg-slate-200 border-gray-200 ">
        <td class="py-3 px-6 text-left font-poppins font-bold">
            Status Request
        </td>

        <td class="py-3 px-6 text-center font-poppins">
            <?php if($data->status_izin == null): ?>
                <div class="flex">
                    <span class="font-poppins bg-yellow-300 text-dark font-semibold py-1 px-3 rounded text-xs">
                        Menunggu Persetujuan
                    </span>
                </div>
            <?php elseif($data->status_izin == 1): ?>
                <div class="flex">
                    <span class="font-poppins bg-green-700 text-slate-50 py-1 px-3 rounded text-xs">
                        Disetujui
                    </span>
                </div>
            <?php elseif($data->status_izin == 2): ?>
                <div class="flex">
                    <span class="font-poppins bg-red-500 text-slate-50 py-1 px-3 rounded text-xs">
                        Ditolak
                    </span>
                </div>
            <?php endif; ?>
        </td>
    </tr>

    <tr class="border-b border-gray-200 ">
        <td class="py-3 px-6 text-left font-poppins font-bold">
            <?php if($data->status_izin == 1): ?>
                Disetujui oleh
            <?php elseif($data->status_izin == 2): ?>
                Ditolak oleh
            <?php else: ?>
                Membutuhkan konfirmasi
            <?php endif; ?>
        </td>

        <td class="py-3 px-6 text-left font-poppins">
            <?php echo e(!empty($data->toPetugas->nama) ? $data->toPetugas->nama : 'Pengurus Asrama'); ?>

        </td>
    </tr>

    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </table>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/mahasiswa/izin-sakit/detail.blade.php ENDPATH**/ ?>