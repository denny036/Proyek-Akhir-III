

<?php $__env->startSection('title'); ?>
    <title>Portal Koordinator</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('koordinator.show.asrama')); ?>"><span class="text-gray-600">Data Asrama / </a></span>Edit
    Data Asrama
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-4">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <div class="h-screen flex justify-start w-full">
        <form action="<?php echo e(route('koordinator.update.data-asrama', $asrama->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>

            <?php if(Session::get('success')): ?>
                <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800"
                    role="alert">
                    <span class="font-medium font-poppins"><?php echo e(Session::get('success')); ?></span>
                </div>
            <?php endif; ?>

            <?php if(Session::get('fail')): ?>
                <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800"
                    role="alert">
                    <span class="font-medium font-poppins"><?php echo e(Session::get('fail')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white px-10 py-7 rounded-xl w-screen shadow-md max-w-lg">
                <div class="space-y-4">
                    <h1 class="text-center text-2xl font-semibold text-gray-600 font-poppins">Edit Data Asrama</h1>
                    <div>
                        <label for="nama_asrama" class="block mb-1 text-gray-600 font-semibold font-poppins">Nama
                            Asrama</label>
                        <input type="text" name="nama_asrama"
                            class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e($asrama->nama_asrama); ?>">
                        <span class="text-red-800 text-sm font-poppins">
                            <?php $__errorArgs = ['nama_asrama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div>
                        <label for="jenis_asrama" class="block mb-1 text-gray-600 font-semibold font-poppins">Jenis
                            Asrama</label>
                        <select name="jenis_asrama" id="jenis_asrama"
                            class="bg-indigo-50 border  text-gray-900 text-sm  focus:ring-blue-500 
            focus:border-blue-500 block  px-4 py-2 outline-none rounded-md w-full
                      dark:text-dark dark:focus:ring-blue-500 dark:focus:border-blue-500 font-poppins">

                            <option value="Pilih Jenis Asrama" disabled selected class="font-poppins">Pilih Jenis Asrama
                            </option>
                            <option class="font-poppins" value="laki-laki"
                                <?php echo e($asrama->jenis_asrama == 'laki-laki' ? 'selected' : ''); ?>">Laki-Laki</option>
                            <option class="font-poppins" value="perempuan"
                                <?php echo e($asrama->jenis_asrama == 'perempuan' ? 'selected' : ''); ?>">Perempuan</option>

                        </select>

                    </div>

                    <div>
                        <label for="lokasi_asrama" class="block mb-1 text-gray-600 font-semibold font-poppins">Lokasi
                            Asrama</label>
                        <select name="lokasi_asrama" id="lokasi_asrama"
                            class="bg-indigo-50 border  text-gray-900 text-sm  focus:ring-blue-500 
            focus:border-blue-500 block  px-4 py-2 outline-none rounded-md w-full
                      dark:text-dark dark:focus:ring-blue-500 dark:focus:border-blue-500 font-poppins">

                            <option value="Pilih Lokasi Asrama" disabled selected class="font-poppins">Pilih Lokasi Asrama
                            </option>
                            
                            <option class="font-poppins" value="Asrama Dalam Kampus"
                                <?php echo e($asrama->lokasi_asrama == 'Asrama Dalam Kampus' ? 'selected' : ''); ?>">Asrama Dalam
                                Kampus</option>
                            <option class="font-poppins" value="Asrama Luar Kampus"
                                <?php echo e($asrama->lokasi_asrama == 'Asrama Luar Kampus' ? 'selected' : ''); ?>">Asrama Luar Kampus
                            </option>
                        </select>
                    </div>
                </div>

                <button type="submit"
                    class="w-28 px-4 py-2 mt-4 text-sm text-center text-white 
        bg-login rounded-md hover:bg-login font-poppins">Simpan</button>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('koordinator.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/koordinator/asrama/edit.blade.php ENDPATH**/ ?>