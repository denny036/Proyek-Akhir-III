

<?php $__env->startSection('title'); ?>
    <title>Portal Mahasiswa</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('mahasiswa.show.check-in')); ?>"><span class="text-gray-600">Data Check In / </a></span>Request Check In
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-6">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <!-- component -->
    <div class="h-screen flex justify-start w-full">
        <form action="<?php echo e(route('mahasiswa.store.check-in')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            
            <?php if(Session::get('success')): ?>
                <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800"
                    role="alert">
                    <span class="font-medium font-poppins"><?php echo e(Session::get('success')); ?></span>
                </div>
            <?php endif; ?>

            <?php if(Session::get('fail')): ?>
                <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800"
                    role="alert">
                    <span class="font-medium font-poppins"><?php echo e(Session::get('fail')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white px-10 py-7 rounded-xl w-screen shadow-md max-w-lg">
                <div class="space-y-4">
                    <h1 class="text-center text-2xl font-semibold text-gray-600 font-poppins">Request Check In</h1>
                    <div>
                        <label for="nim" class="block mb-1 text-gray-600 font-semibold font-poppins">NIM</label>
                        <input type="text" class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e($dataMahasiswa->nim); ?>" disabled />
                    </div>
                    <div>
                        <label for="nama" class="block mb-1 text-gray-600 font-semibold font-poppins">Nama</label>
                        <input type="text" class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e($dataMahasiswa->nama); ?>" disabled />
                    </div>
                    <div>
                        <label for="angkatan" class="block mb-1 text-gray-600 font-semibold font-poppins">Angkatan</label>
                        <input type="text" class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e($dataMahasiswa->angkatan); ?>" disabled />
                    </div>

                    <div>
                        <label for="asal_asrama" class="block mb-1 text-gray-600 font-semibold font-poppins">Asal
                            Asrama</label>
                        <input type="text" class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e($dataMahasiswa->nama_asrama); ?>" disabled />
                    </div>

                    <div>
                        <label for="asrama_tujuan" class="block mb-1 text-gray-600 font-semibold font-poppins">Asrama
                            Tujuan</label>
                        <select name="asrama_tujuan" id="asrama_tujuan"
                            class="bg-indigo-50 border  text-gray-900 text-sm  focus:ring-blue-500 
            focus:border-blue-500 block  px-4 py-2 outline-none rounded-md w-full
                      dark:text-dark dark:focus:ring-blue-500 dark:focus:border-blue-500 font-poppins">

                            <option value="Pilih Asrama" disabled selected class="font-poppins">Pilih Asrama</option>

                            <?php $__currentLoopData = $dataAsrama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" class="font-poppins"><?php echo e($item->nama_asrama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            

                        </select>

                    </div>

                    <div>
                        <label for="tanggal_check_in" class="block mb-1 text-gray-600 font-semibold font-poppins">Tanggal
                            Check In</label>
                        <input type="datetime-local" name="tanggal_check_in"
                            class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins" />
                    </div>

                    <div>
                        <label for="keperluan" class="block mb-1 text-gray-600 font-semibold font-poppins">Keperluan</label>
                        <textarea id="keperluan" name="keperluan" rows="4"
                            class="bg-indigo-50 
                px-4 py-2 outline-none rounded-md w-full text-sm font-poppins">
                </textarea>
                    </div>


                </div>

                <button type="submit"
                    class="w-28 px-4 py-2 mt-4 text-sm text-center text-white 
        bg-login rounded-md hover:bg-login font-poppins">Kirim</button>

            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/mahasiswa/check-in/create.blade.php ENDPATH**/ ?>