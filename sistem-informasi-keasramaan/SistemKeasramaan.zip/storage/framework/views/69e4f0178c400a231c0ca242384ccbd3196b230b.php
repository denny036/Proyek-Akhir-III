

<?php $__env->startSection('title'); ?>
    <title>Portal Koordinator</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('koordinator.home')); ?>"><span class="text-gray-600">Home / </a></span>Daftar Penghuni Asrama
    <?php echo e($asramaID->nama_asrama); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <div class="bg-white shadow rounded-sm my-2.5 overflow-x-auto">

        <table class="min-w-max w-full table-auto">
            <thead>
                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th class="py-3 px-6 text-left">Nama Mahasiswa</th>
                    <th class="py-3 px-6 text-left">NIM</th>
                    <th class="py-3 px-6 text-center">Angkatan</th>
                    <th class="py-3 px-6 text-center">Prodi</th>
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $dataPenghuniAsrama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="text-gray-600 text-sm">
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
                            <?php echo e($value->nama); ?>

    </div>
    </td>
    <td class="py-3 px-6 text-left">
        <div class="flex items-center">
            <span class="font-poppins">
                <?php echo e($value->nim); ?>

            </span>
        </div>
    </td>
    <td class="py-3 px-6 text-center font-poppins">
        <?php echo e($value->angkatan); ?>

    </td>
    <td class="py-3 px-6 text-center">
        <?php echo e(Str::of($value->prodi)->upper()->explode('_')->implode(' ')); ?>

    </td>
    <td class="py-3 px-6 text-center">
        <div class="flex item-center justify-center">
            <span class="bg-blue-500 text-slate-50 py-1 px-3 rounded-full text-xs">
                <a href="#">Detail</a>
            </span>
        </div>
    </td>
    </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </table>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($dataPenghuniAsrama->links('pagination::tailwind')); ?>

        </div>
    </div>

    </div>

    <div class="py-6">
        <h1 class="font-poppins text-lg font-bold">
            Daftar Petugas Asrama <?php echo e($asramaID->nama_asrama); ?>

        </h1>
        <div class="border-gray-300 py-1 text-white border-b rounded">

        </div>
        <div class="py-4 text-gray-400 space-y-1">
            <table class="min-w-max w-full table-auto">
                <thead>
                    <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                        <th class="py-3 px-6 text-left">Nama Petugas</th>
                        <th class="py-3 px-6 text-left">Email</th>
                        <th class="py-3 px-6 text-center">Jabatan</th>
                        <th class="py-3 px-6 text-center">Aksi</th>
                    </tr>
                </thead>

                <?php $__currentLoopData = $daftarPetugasAsrama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody class="text-gray-600 text-sm">
                        <tr class="border-b border-gray-200 hover:bg-gray-100">
                            <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
                                <?php echo e($object->nama); ?>

        </div>
        </td>
        <td class="py-3 px-6 text-left">
            <div class="flex items-center">
                <span class="font-poppins">
                    <?php echo e($object->email); ?>

                </span>
            </div>
        </td>
        <td class="py-3 px-6 text-center font-poppins">
            <?php echo e($object->jabatan); ?>

        </td>

        <td class="py-3 px-6 text-center">
            <div class="flex item-center justify-center">

                <span class="bg-blue-500 text-slate-50 py-1 px-3 rounded-full text-xs">Detail</span>
            </div>
        </td>
        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </table>
        <div class="row">
            <div class="col-md-12">
                <?php echo e($daftarPetugasAsrama->links('pagination::tailwind')); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('koordinator.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/koordinator/home/keasramaan.blade.php ENDPATH**/ ?>