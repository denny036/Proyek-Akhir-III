

<?php $__env->startSection('title'); ?>
    <title>Portal Petugas</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('petugas.home')); ?>"><span class="text-gray-600">Home / </a></span>Daftar Check Out Mahasiswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-2">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <?php if(Session::get('success-check-out')): ?>
        <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800"
            role="alert">
            <span class="font-medium font-poppins"><?php echo e(Session::get('success-check-out')); ?></span>
        </div>
    <?php endif; ?>

    <?php if(Session::get('fail-check-out')): ?>
        <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800" role="alert">
            <span class="font-medium font-poppins"><?php echo e(Session::get('fail-check-out')); ?></span>
        </div>
    <?php endif; ?>
    <p class="font-poppins font-normal text-lg py-2">Daftar Request Check Out Mahasiswa</p>
    <div class="bg-white shadow rounded-sm my-2.5 overflow-x-auto">

        <table class="min-w-max w-full table-auto">
            <thead>
                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th class="py-3 px-6 text-left">Nama</th>
                    <th class="py-3 px-6 text-left">NIM</th>
                    <th class="py-3 px-6 text-center">Asrama Asal</th>
                    <th class="py-3 px-6 text-center">Tanggal Check Out</th>
                    <th class="py-3 px-6 text-center">Status Permohonan</th>
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $daftarRequestCheckOut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="text-gray-600 text-sm">
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
                            <?php echo e($data->isAnyMahasiswa->nama); ?>

    </div>
    </td>

    <td class="py-3 px-6 text-left">
        <div class="flex items-center">
            <span class="font-poppins">
                <?php echo e($data->isAnyMahasiswa->nim); ?>

            </span>
        </div>
    </td>

    
    <td class="py-3 px-6 text-center font-poppins">
        <?php echo e($data->nama_asrama); ?>

    </td>

    

    <td class="py-3 px-6 text-center font-poppins">
        <?php echo e(\Carbon\Carbon::parse($data->tanggal_check_out)->isoFormat('DD MMMM YYYY H:mm')); ?>

    </td>

    <td class="py-3 px-6 text-center font-poppins">
        <?php if($data->status_request == null): ?>
            <div class="flex item-center justify-center">
                <span class="font-poppins bg-yellow-300 text-dark font-semibold py-1 px-3 rounded-full text-xs">
                    Menunggu Persetujuan
                </span>
            </div>
        <?php elseif($data->status_request == 1): ?>
            <div class="flex item-center justify-center">
                <span class="font-poppins bg-green-700 text-slate-50 py-1 px-3 rounded-full text-xs">
                    Disetujui
                </span>
            </div>
        <?php elseif($data->status_request == 2): ?>
            <div class="flex item-center justify-center">
                <span class="font-poppins bg-red-500 text-slate-50 py-1 px-3 rounded-full text-xs">
                    Ditolak
                </span>
            </div>
        <?php endif; ?>
    </td>

    <td class="py-3 px-6 text-center">
        <div class="flex item-center justify-center">
            <span class="bg-blue-500 text-slate-50 py-1 px-3 rounded-full text-xs font-poppins">
                <a href="<?php echo e(route('petugas.detail-check-out', $data->id)); ?>">Detail</a>
            </span>
        </div>
    </td>
    </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </table>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($daftarRequestCheckOut->links('pagination::tailwind')); ?>

        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('petugas.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/petugas/check-out/index.blade.php ENDPATH**/ ?>