

<?php $__env->startSection('title'); ?>
    <title>Portal Petugas</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('petugas.home')); ?>"><span class="text-gray-600">Home / </a></span>Data Petugas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-2">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    
    <p class="font-poppins font-normal text-lg py-2">Daftar Petugas Asrama &mdash; Institut Teknologi Del</p>
    <div class="bg-white shadow rounded-sm my-2.5 overflow-x-auto">

        <table class="min-w-max w-full table-auto">
            <thead>
                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th class="py-3 px-6 text-left">Nama</th>
                    <th class="py-3 px-6 text-left">Jenis Kelamin</th>
                    <th class="py-3 px-6 text-center">Jabatan</th>
                    <th class="py-3 px-6 text-center">Lokasi Bertugas</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $dataPetugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lists): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="text-gray-600 text-sm">
                    <tr class="border-b border-gray-200 hover:bg-gray-100">
                        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
                            <?php echo e($lists->nama); ?>

    </div>
    </td>
    <td class="py-3 px-6 text-left">
        <div class="flex items-center">
            <span class="font-poppins">
                <?php echo e(Str::of($lists->jenis_kelamin)->ucfirst()->explode('_')->implode(' ')); ?>

            </span>
        </div>
    </td>
    <td class="py-3 px-6 text-center font-poppins">
        <?php echo e($lists->jabatan); ?>

    </td>

    <td class="py-3 px-6 text-center font-poppins">
        <?php echo e($lists->asrama->nama_asrama); ?>

    </td>

    </tr>
    </tbody>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </table>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($dataPetugas->links('pagination::tailwind')); ?>

        </div>
    </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('petugas.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/petugas/data-petugas.blade.php ENDPATH**/ ?>