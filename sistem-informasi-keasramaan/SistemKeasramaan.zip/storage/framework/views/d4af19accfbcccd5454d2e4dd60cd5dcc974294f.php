

<?php $__env->startSection('title'); ?>
    <title>Portal Mahasiswa</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('mahasiswa.home')); ?>"><span class="text-gray-600">Home / </a></span>Izin Bermalam
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-2">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <a href="<?php echo e(route('mahasiswa.request.izin-bermalam')); ?>">
        <button type="button"
            class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 
    focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 
    dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 font-poppins">Request
            IB</button></a>

    <p class="font-poppins font-normal text-lg py-2">Request sebelumnya</p>
    <div class="bg-white shadow rounded-sm my-2.5 overflow-x-auto">

        <table class="min-w-max w-full table-auto">
            <thead>
                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th class="py-3 px-6 text-left">Status Permohonan</th>
                    <th class="py-3 px-6 text-left">Oleh</th>
                    <th class="py-3 px-6 text-center">Keperluan IB</th>
                    <th class="py-3 px-6 text-center">Tempat Tujuan</th>
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $riwayatIB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="text-gray-600 text-sm">
                    <tr class="border-b border-gray-200 hover:bg-gray-100">

                        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
                            <?php if($data->status == null): ?>
                                <div class="flex item-center">
                                    <span
                                        class="font-poppins bg-yellow-300 text-dark font-semibold py-1 px-3 rounded-full text-xs">
                                        Menunggu Persetujuan
                                    </span>
                                </div>
                            <?php elseif($data->status == 1): ?>
                                <div class="flex item-center">
                                    <span class="font-poppins bg-green-700 text-slate-50 py-1 px-3 rounded-full text-xs">
                                        Disetujui
                                    </span>
                                </div>
                            <?php elseif($data->status == 2): ?>
                                <div class="flex item-center">
                                    <span class="font-poppins bg-red-500 text-slate-50 py-1 px-3 rounded-full text-xs">
                                        Ditolak
                                    </span>
                                </div>
                            <?php endif; ?>

                        </td>

                        <td class="py-3 px-6 text-left">
                            <div class="flex items-center">
                                <span class="font-poppins">
                                <?php echo e(!empty($data->petugas->nama) ? $data->petugas->nama:' '); ?>

                                </span>
                            </div>
                        </td>
                        <td class="py-3 px-6 text-center font-poppins">
                            <?php echo e($data->keperluan_ib); ?>

                        </td>
                        <td class="py-3 px-6 text-center font-poppins">
                            <?php echo e($data->tempat_tujuan); ?>

                        </td>
                        <td class="py-3 px-6 text-center">
                            <div class="flex item-center justify-center">
                                <span class="bg-blue-500 text-slate-50 py-1 px-3 rounded-full text-xs font-poppins">
                                    <a href="<?php echo e(route('mahasiswa.detail.izin-bermalam', encrypt($data->id))); ?>">Detail</a>
                                </span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </table>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($riwayatIB->links('pagination::tailwind')); ?>

        </div>
    </div>

    </div>

    <p class="font-poppins font-normal text-lg py-2">Pedoman Izin Bermalam</p>
    <div class="flex border-b border-gray-300"></div>
    <ul class="list-disc px-4 font-poppins text-base text-justify">
        <li>
            Mahasiswa diberikan Izin Bermalam di Luar Kampus (IBL) di hari Jumat atau Sabtu atau di hari lain dimana
            keesokan harinya tidak ada kegiatan akademik atau kegiatan lainnya yang tidak mengharuskan mahasiswa berada di
            kampus IT Del.
        </li>
        <li>
            Mahasiswa yang IBL wajib menjaga nama baik IT Del di luar kampus.
        </li>
        <li>
            Mahasiswa mengisi pengajuan IBL selambatnya H-2. Dan mencetak form IBL untuk ditandatangani Bapak/Ibu Asrama dan
            ditunjukan di Pos Satpam saat keluar kampus.
        </li>
        <li>
            Pada saat kembali ke kampus, mahasiswa mengumpulkan kertas IBL yang telah ditandatangani oleh orangtua di Pos
            Satpam untuk selanjutnya dikumpulkan dan direkap oleh Pembina Asrama.
        </li>
        <li>
            Apabila terdapat kegiatan Badan Eksekutif Mahasiswa (BEM) yang mengharuskan seluruh mahasiswa mengikuti kegiatan
            tersebut, maka mahasiswa tidak diperbolehkan IBL.
        </li>
        <li>
            Mahasiswa yang tidak mengajukan IBL sesuai ketentuan pada butir 3 (tiga) tidak diizinkan untuk IBL kecuali dalam
            kondisi mendesak (emergency) seperti sakit atau ada keluarga meninggal.
        </li>
    </ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/mahasiswa/izin-bermalam/index.blade.php ENDPATH**/ ?>