<style>
    * {box-sizing: border-box;}
    .all-columns{
        float: left;
        width: 32.33%;
        padding: 1px;
        text-align: center;
    }

    .all-rows:after{
        content: "";
        display: table;
        clear: both;
    }

    .text-name {
        padding-top: 45px;
    }

    .text-info{
        line-height: 0.1;
    }

    .text-realisasi{
        line-height: 1.7;
    }
</style>

<?php $__currentLoopData = $dataIB; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <h3 style="font-size: 18px"><u>Surat Izin Bermalam Mahasiswa</h3></u><br><br><br>



    <p>DIBERIKAN IZIN BERMALAM KEPADA:</p>
    <p class="text-nama">Nama: <?php echo e($item->nama); ?></p><br>
    
    <p><b>Rencana IB</b></p>
    <p class="text-info">Tanggal Berangkat: <?php echo e(\Carbon\Carbon::parse($item->rencana_berangkat)->isoFormat('DD MMMM YYYY')); ?>

        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span>Pukul: <?php echo e(\Carbon\Carbon::parse($item->rencana_berangkat)->isoFormat('H:mm:ss')); ?></span>
    </p>
    <p class="text-info">Keperluan: <?php echo e($item->keperluan_ib); ?></p>
    <p class="text-info">Tanggal Kembali: <?php echo e(\Carbon\Carbon::parse($item->rencana_kembali)->isoFormat('DD MMMM YYYY')); ?>

        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        <span>Pukul: <?php echo e(\Carbon\Carbon::parse($item->rencana_kembali)->isoFormat('H:mm:ss')); ?></span>
    </p>
    <p class="text-info">Tujuan: <?php echo e($item->tempat_tujuan); ?></p>

    <br>
    

    <div class="all-rows">
        <div class="all-columns">
            <p>Pemohon</p>
            <p class="text-name">(<?php echo e($item->nama); ?>)</p>
        </div>
        <div class="all-columns">
            <p>Menyetujui, petugas</p>
            <p class="text-name">(<?php echo e($item->petugas->nama); ?>)</p>
        </div>
        <div class="all-columns">
            <p>Diketahui, orangtua/wali</p>
            <p class="text-name">(.........................................)</p>
        </div>
    </div>

    <p style="color: #fc3003; text-align: justify; font-size: 11px;">* Sebelum meninggalkan asrama untuk IB, mahasiswa/i
        dianjurkan untuk permisi kepada Bapak/Ibu asrama atau Abang/Kakak asrama.</p>
    <hr>
    <p class="text-realisasi"><b>Realisasi IB (diisi oleh petugas)</b></p>
    Tanggal kembali: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>Pukul:
    </span>

    <p>Petugas</p><br><br>

    (.........................................)
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/mahasiswa/izin-bermalam/print.blade.php ENDPATH**/ ?>