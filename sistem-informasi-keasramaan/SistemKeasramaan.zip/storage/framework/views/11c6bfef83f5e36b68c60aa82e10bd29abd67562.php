

<?php $__env->startSection('title'); ?>
    <title>Portal Mahasiswa</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('mahasiswa.izin-sakit')); ?>"><span class="text-gray-600">Izin Sakit / </a></span>Request Izin
    Sakit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-4">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <div class="h-screen flex justify-start w-full">
        <form action="<?php echo e(route('mahasiswa.store.izin-sakit')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php if(Session::get('success')): ?>
                <div class="p-4 mb-4 text-sm text-green-700 bg-green-100 rounded-lg dark:bg-green-200 dark:text-green-800"
                    role="alert">
                    <span class="font-medium font-poppins"><?php echo e(Session::get('success')); ?></span>
                </div>
            <?php endif; ?>

            <?php if(Session::get('fail')): ?>
                <div class="p-4 mb-4 text-sm text-red-700 bg-red-100 rounded-lg dark:bg-red-200 dark:text-red-800"
                    role="alert">
                    <span class="font-medium font-poppins"><?php echo e(Session::get('fail')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white px-10 py-7 rounded-xl w-screen shadow-md max-w-lg">
                <div class="space-y-4">
                    <h1 class="text-left text-2xl font-normal text-gray-600 font-poppins">Request Izin Sakit</h1>

                    <div>
                        <label for="asrama_mahasiswa" class="block mb-1 text-gray-600 font-semibold font-poppins">Asrama</label>
                        <input type="text" name="asrama_mahasiswa"
                            class="bg-indigo-50 opacity-70 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e($dataMahasiswa->nama_asrama); ?>" disabled>
                    </div>

                    <div>
                        <label for="jadwal_istirahat" class="block mb-1 text-gray-600 font-semibold font-poppins">Mulai istirahat</label>
                        <input type="datetime-local" name="jadwal_istirahat"
                            class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full font-poppins"
                            value="<?php echo e(old('jadwal_istirahat')); ?>">
                        <span class="text-red-800 text-sm font-poppins">
                            <?php $__errorArgs = ['jadwal_istirahat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div>
                        <label for="keterangan" class="block mb-1 text-gray-600 font-semibold font-poppins">Keterangan
                            Izin Sakit</label>
                        <textarea name="keterangan" id="keterangan" rows="4"
                            class="bg-indigo-50 px-4 py-2 outline-none rounded-md 
            w-full font-poppins"></textarea>
                        <span class="text-red-800 text-sm font-poppins">
                            <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                    <div>
                        <label for="surat_sakit" class="block mb-1 text-gray-600 font-semibold font-poppins">Lampiran Surat Sakit
                            </label>
                        <input type="file" name="surat_sakit"
                            class="bg-indigo-50 px-4 py-2 outline-none rounded-md w-full cursor-pointer font-poppins"
                            value="<?php echo e(old('surat_sakit')); ?>">
                            <p class="italic mt-1 text-xs text-black font-poppins">Silakan lampirkan surat keterangan sakit dari dokter jika ada.</p>
                        <span class="text-red-800 text-sm font-poppins">
                            <?php $__errorArgs = ['surat_sakit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <?php echo e($message); ?>

                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </span>
                    </div>

                </div>

                <button type="submit"
                    class="w-28 px-4 py-2 mt-4 text-sm text-center text-white 
        bg-login rounded-md hover:bg-login font-poppins">Simpan</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/mahasiswa/izin-sakit/create.blade.php ENDPATH**/ ?>