<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Register</title>
        
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
       
    </head>

    <body>
        <div class="w-full h-screen bg-no-repeat bg-cover" style="background-image: url('https://i.ibb.co/56qkQjB/login.png');">
            <div class="flex items-center justify-center h-screen font-poppins sm:px-6">
                <div class="w-full max-w-sm p-4 bg-neutral-50 rounded-md shadow-md sm:p-6">
                    <img src="../images/logo.png" alt="Logo-Del" class="bg-auto w-28 mx-auto">
                    <div class="flex items-center justify-center mt-2">
                    <span class="text-xs text-gray-500">Institut Teknologi Del</span>
                    </div>
                    <div class="flex items-center justify-center">
                        <span class="text-xl font-medium text-slate-900 mt-2">Portal Registrasi Mahasiswa</span>
                    </div>

                    <form class="mt-4" action="#" method="POST">
                        <label for="nama" class="block">
                            <span class="text-sm text-login">Nama</span>
                            <input type="text" id="nama" name="nama" autocomplete="nama"
                                class="block w-full px-3 py-2 mt-1 text-slate-900 bg-gray-200 rounded-md focus:outline-none focus:shadow-outline placeholder:text-slate-800"
                                placeholder="Masukkan nama lengkap" minlength="3" maxlength="21" required/>
                        </label>
                        <label for="nim" class="block">
                            <span class="text-sm text-login">NIM</span>
                            <input type="text" id="nim" name="nim" autocomplete="nim"
                                class="block w-full px-3 py-2 mt-1 text-slate-900 bg-gray-200 rounded-md focus:outline-none focus:shadow-outline placeholder:text-slate-800"
                                placeholder="Nomor Induk Mahasiswa" minlength="8" maxlength="8" required/>
                        </label>
                        <label for="password" class="block mt-3">
                            <span class="text-sm text-login">Password</span>
                            <input type="password" id="password" name="password" autocomplete="current-password"
                                class="block w-full px-3 py-2 mt-1 text-slate-900 bg-gray-200 rounded-md focus:outline-none focus:shadow-outline placeholder:text-slate-800"
                                placeholder="Masukkan password" minlength="8" required/>
                        </label>
                        <label for="confirm_password" class="block mt-3">
                            <span class="text-sm text-login">Confirm Password</span>
                            <input type="password" id="confirm_password" name="confirm_password" autocomplete="confirm_password"
                                class="block w-full px-3 py-2 mt-1 text-slate-900 bg-gray-200 rounded-md focus:outline-none focus:shadow-outline placeholder:text-slate-800"
                                placeholder="Masukkan confirm password" required/>
                        </label>
                        <label for="angkatan" class="block mt-3">
                            <span class="text-sm text-login">Angkatan</span>
                            <select id="angkatan" required class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 
                            dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 
                                    dark:text-dark dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="2022">2022</option>
                                <option value="2021">2021</option>
                                <option value="2020">2020</option>
                                <option value="2019">2019</option>
                                <option value="2018">2018</option>
                                <option value="2017">2017</option>
                                <option value="2016">2016</option>
                            </select>
                        </label>
                        <label for="prodi" class="block mt-3">
                            <span class="text-sm text-login">Program Studi</span>
                            <select id="prodi" required class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 
                            dark:bg-gray-200 dark:border-gray-600 dark:placeholder-gray-400 
                                    dark:text-dark dark:focus:ring-blue-500 dark:focus:border-blue-500">
                                <option value="informatika">Informatika</option>
                                <option value="sistem_informasi">Sistem Informasi</option>
                                <option value="teknik_elektro">Teknik Elektro</option>
                                <option value="teknik_bioproses">Teknik Bioproses</option>
                                <option value="manajemen_rekayasa">Manajemen Rekayasa</option>
                                <option value="d4_trpl">D4 Teknologi Rekayasa Perangkat Lunak</option>
                                <option value="d3_ti">D3 Teknologi Informasi</option>
                                <option value="d3_tk">D3 Teknologi Komputer</option>
                            </select>
                        </label>
                        
                        <div class="mt-6 text-center">
                            <p class="text-slate-900 text-xs sm:text-center mx-8">Sudah punya akun? Silakan masuk <a href="<?php echo e(route('user')); ?>" class="text-login">kesini.</a>
                            <button type="submit"
                                class="w-28 px-4 py-2 mt-4 text-sm text-center text-white bg-login rounded-md hover:bg-login">Daftar</button>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
        
    </body>
</html><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/auth/register.blade.php ENDPATH**/ ?>