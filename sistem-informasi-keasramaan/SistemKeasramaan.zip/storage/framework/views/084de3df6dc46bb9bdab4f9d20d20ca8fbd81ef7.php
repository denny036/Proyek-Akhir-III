

<?php $__env->startSection('title'); ?>
    <title>Portal Mahasiswa</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-navigasi'); ?>
    Keasramaan IT Del
<?php $__env->stopSection(); ?>

<?php $__env->startSection('judul-halaman'); ?>
    <a href="<?php echo e(route('mahasiswa.home')); ?>"><span class="text-gray-600">Home / </a></span>Izin Sakit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('statistics'); ?>
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 py-2">
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('table'); ?>
    <a href="<?php echo e(route('mahasiswa.request.izin-sakit')); ?>">
        <button type="button"
            class="focus:outline-none text-white bg-green-700 hover:bg-green-800 focus:ring-4 
    focus:ring-green-300 font-medium rounded-lg text-sm px-5 py-2.5 mr-2 mb-2 
    dark:bg-green-600 dark:hover:bg-green-700 dark:focus:ring-green-800 font-poppins">Request
            Izin Sakit</button></a>

    <p class="font-poppins font-normal text-lg py-2">Request sebelumnya</p>
    <div class="bg-white shadow rounded-sm my-2.5 overflow-x-auto">

        <table class="min-w-max w-full table-auto">
            <thead>
                <tr class="bg-gray-200 text-gray-600 uppercase text-sm leading-normal">
                    <th class="py-3 px-6 text-left">Status Permohonan</th>
                    <th class="py-3 px-6 text-left">Oleh</th>
                    <th class="py-3 px-6 text-center">Jadwal Istirahat</th>
                    <th class="py-3 px-6 text-left">Kondisi</th>
                    <th class="py-3 px-6 text-center">Keterangan</th>
                    <th class="py-3 px-6 text-center">Aksi</th>
                </tr>
            </thead>
            <?php $__currentLoopData = $riwayatIS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tbody class="text-gray-600 text-sm">
                    <tr class="border-b border-gray-200 hover:bg-gray-100">

                        <td class="py-3 px-6 text-left whitespace-nowrap font-poppins">
                            <?php if($data->status_izin == null): ?>
                                <div class="flex item-center">
                                    <span
                                        class="font-poppins bg-yellow-300 text-dark font-semibold py-1 px-3 rounded-full text-xs">
                                        Menunggu Persetujuan
                                    </span>
                                </div>
                            <?php elseif($data->status_izin == 1): ?>
                                <div class="flex item-center">
                                    <span class="font-poppins bg-green-700 text-slate-50 py-1 px-3 rounded-full text-xs">
                                        Disetujui
                                    </span>
                                </div>
                            <?php elseif($data->status_izin == 2): ?>
                                <div class="flex item-center">
                                    <span class="font-poppins bg-red-500 text-slate-50 py-1 px-3 rounded-full text-xs">
                                        Ditolak
                                    </span>
                                </div>
                            <?php endif; ?>

                        </td>

                        <td class="py-3 px-6 text-left">
                            <div class="flex items-center">
                                <span class="font-poppins">
                                <?php echo e(!empty($data->toPetugas->nama) ? $data->toPetugas->nama:' '); ?>

                                </span>
                            </div>
                        </td>
                        
                        <td class="py-3 px-6 text-center font-poppins">
                            <?php echo e(\Carbon\Carbon::parse($data->jadwal_istirahat)->isoFormat('DD MMMM YYYY H:mm')); ?>

                        </td>

                        <td class="py-3 px-6 text-center font-poppins">
                            <?php if($data->kondisi == "sakit"): ?>
                                <div class="flex item-center">
                                    <span
                                        class="font-poppins py-1 px-3 rounded-full text-sm">
                                        Sakit
                                    </span>
                                </div>
                            <?php else: ?>
                            <div class="flex item-center">
                                <span
                                    class="font-poppins py-1 px-3 rounded-full text-sm">
                                    Sembuh
                                </span>
                            </div>
                            <?php endif; ?>
                        </td>

                        <td class="py-3 px-6 text-center font-poppins">
                            <?php echo e($data->keterangan); ?>

                        </td>

                        <td class="py-3 px-6 text-center">
                            <div class="flex item-center justify-center">
                                <span class="bg-blue-500 text-slate-50 py-1 px-3 rounded-full text-xs font-poppins">
                                    <a href="<?php echo e(route('mahasiswa.detail.izin-sakit', encrypt($data->id))); ?>">Detail</a>
                                </span>
                            </div>
                        </td>
                    </tr>
                </tbody>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    </table>
    <div class="row">
        <div class="col-md-12">
            <?php echo e($riwayatIS->links('pagination::tailwind')); ?>

        </div>
    </div>

    </div>
    
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('mahasiswa.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\Proyek-Akhir-III\sistem-informasi-keasramaan\resources\views/mahasiswa/izin-sakit/index.blade.php ENDPATH**/ ?>